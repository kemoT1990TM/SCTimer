package eu.unicredit.gimbta.listeners;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.IClassListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestClass;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.xml.XmlSuite.ParallelMode;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import eu.unicredit.gimbta.testcase.base.TestBase;
import eu.unicredit.gimbta.utilities.ExtentManager;
import eu.unicredit.gimbta.utilities.TestUtil;

public class CustomListener implements IClassListener, ITestListener, ISuiteListener {
	protected static final Logger log = Logger.getLogger(CustomListener.class.getName());	
	private ExtentReports report = ExtentManager.getInstance();
	private static ParallelMode parallelMode;
	
	public void onFinish(ITestContext testCtx) {
		if(ParallelMode.NONE.equals(parallelMode) || ParallelMode.TESTS.equals(parallelMode))
			tearDown();
	}

	public void onStart(ITestContext testCtx) {
		log.debug(String.format("Thread %d Running Test setUp...%n", Thread.currentThread().getId()));
		if(ParallelMode.NONE.equals(parallelMode) || ParallelMode.TESTS.equals(parallelMode))
			TestBase.setUp((String)testCtx.getCurrentXmlTest().getParameter("country"));		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub
	}

	public void onTestFailure(ITestResult arg0) {
		System.setProperty("org.uncommons.reportng.escape-output","false");
		try {
			TestUtil.captureScreenshot();
		} catch (IOException e) {
			e.printStackTrace();
		}
		TestBase.getExtTest().log(LogStatus.FAIL, arg0.getName()+" Failed with exception : "+arg0.getThrowable());
		TestBase.getExtTest().log(LogStatus.FAIL, TestBase.getTest().addScreenCapture(TestUtil.screenshotName));
		report.endTest(TestBase.getExtTest());
		report.flush();
	}

	public void onTestSkipped(ITestResult testResult) {
		System.out.printf("Test %s was skipped %n", testResult.getMethod().getConstructorOrMethod().getName());
		TestBase.setTest(report.startTest(testResult.getName()));
		TestBase.setExtTest(TestBase.getTest());
		TestBase.getExtTest().log(LogStatus.SKIP, String.format("[%s]  %s.%s()  SKIPPED", TestBase.getCountry().toUpperCase(), 
					testResult.getMethod().getRealClass().getSimpleName(), testResult.getName()));
		report.endTest(TestBase.getExtTest());
		report.flush();
	}

	public void onTestStart(ITestResult testResult) {
		String testName = testResult.getMethod().getConstructorOrMethod().getName();
		//System.out.printf("%nCustomListener::On Test START - Should skip test %s? %s %n", testName, !TestUtil.isTestRunnable(testName));
		if(!TestUtil.isTestRunnable(testName)) {
			testResult.setStatus(ITestResult.SKIP);
			testResult.setThrowable(new SkipException(String.format("Throwing SkipException - Skipping test %s %n", testName)));
			//System.out.printf("%nCustomListener::On Test START - skipping test %s %n", testName);
			throw new SkipException(String.format("Throwing SkipException - Skipping test %s %n", testName));
		}
		TestBase.setTest(report.startTest(testResult.getName()));
		TestBase.setExtTest(TestBase.getTest());
	}

	public void onTestSuccess(ITestResult arg0) {
		TestBase.getExtTest().log(LogStatus.PASS, arg0.getName()+" PASS");
		report.endTest(TestBase.getExtTest());
		report.flush();		
	}

	public void onFinish(ISuite arg0) {
		// TODO Auto-generated method stub
	}

	public void onStart(ISuite suite) {
		log.info("PARALLEL EXECUTION: " + suite.getParallel());
		parallelMode = ParallelMode.valueOf(suite.getParallel().toUpperCase());
	}
	
	private void tearDown() {
		if (TestBase.getDriver() != null) {
			TestBase.getDriver().close();
			TestBase.resetDriver();
		}
		log.debug(String.format("### Thread %d Completed Execution!!!\n\n", Thread.currentThread().getId()));
	}

	@Override
	public void onBeforeClass(ITestClass testClass) {
		if(ParallelMode.CLASSES.equals(parallelMode))
			TestBase.setUp((String)testClass.getXmlTest().getParameter("country"));
	}

	@Override
	public void onAfterClass(ITestClass testClass) {
		if(ParallelMode.CLASSES.equals(parallelMode))
			tearDown();
	}
}
