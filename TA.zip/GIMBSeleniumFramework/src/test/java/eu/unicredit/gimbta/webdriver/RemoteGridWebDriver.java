package eu.unicredit.gimbta.webdriver;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

import org.openqa.selenium.Platform;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class RemoteGridWebDriver extends GenericWebDriver {

	public RemoteGridWebDriver() {
		// CHANGES TO BELOW REMOTE EXECUTION CONFIGURATION ARE DRIVEN AND MUST BE DELIVERED BY TO/GRID RESP. TEAM 
		try {
			String browser = System.getProperty("browser");
			URL seleniumGridURL = new URL(System.getProperty("gridURL"));
			String desiredBrowserVersion = System.getProperty("desiredBrowserVersion");
			String desiredPlatform = System.getProperty("desiredPlatform");

			if (null != desiredPlatform && !desiredPlatform.isEmpty()) {
				capabilities.setPlatform(Platform.valueOf(desiredPlatform.toUpperCase()));
			}

			if (null != desiredBrowserVersion && !desiredBrowserVersion.isEmpty()) {
				capabilities.setVersion(desiredBrowserVersion);
			}
			Date d = new Date();
			String testId = System.getProperty("testName") + "_" + d.toString().replace(":", "_").replace(" ", "_");
			capabilities.setCapability("name", testId);
			capabilities.setCapability("recordVideo", Boolean.getBoolean("recordVideo"));
			capabilities.setCapability(CapabilityType.BROWSER_NAME, browser);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

			if (browser.equals("firefox")) {
				capabilities = DesiredCapabilities.firefox();
				capabilities.setCapability("marionette", true);
				FirefoxOptions options = new FirefoxOptions();
				options.merge(capabilities);
				options.setHeadless(HEADLESS);
			}

			//	if(System.getenv("executionEnvironment")!=null && !System.getenv("executionEnvironment").isEmpty()) {
			//		executionEnvironment = System.getenv("executionEnvironment");
			//		config.setProperty("executionEnvironment", executionEnvironment);
			//	} else {
			//		executionEnvironment = config.getProperty("executionEnvironment");
			//		if(executionEnvironment.equalsIgnoreCase(Constants.ExecutionEnv_LOCAL))
			//			gridExecution = false;
			//		else
			//			gridExecution = true;
			//	}
			
			this.driver = new RemoteWebDriver(seleniumGridURL, capabilities);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}		
	}
}
