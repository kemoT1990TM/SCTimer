package eu.unicredit.gimbta.data;

public class SelectorBean {

	private static final String SPLIT_REGEX = "##";
	private String key;
	private SelectorModes mode;
	private String selector;
	
	public SelectorBean() {
	}
	
	public SelectorBean(String key, String selectorData) {
		Object[] split = selectorData.split(SPLIT_REGEX);
		this.mode = SelectorModes.valueOf((String)split[0]);
		this.selector = (String)split[1];
	}

	public SelectorModes getMode() {
		return mode;
	}

	public String getSelector() {
		return selector;
	}

	public Object getKey() {
		return this.key;
	}
}
