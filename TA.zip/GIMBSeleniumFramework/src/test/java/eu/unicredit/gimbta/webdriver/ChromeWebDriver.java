package eu.unicredit.gimbta.webdriver;

import java.util.HashMap;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;

import eu.unicredit.gimbta.commons.Constants;

public class ChromeWebDriver extends GenericWebDriver {

	public ChromeWebDriver() {
		super();
		System.setProperty("webdriver.chrome.driver", Constants.WEBDRIVER_EXECUTABLES_LOCATION + "chromedriver.exe");
		
		HashMap<String, Object> chromePreferences = new HashMap<>();
		chromePreferences.put("profile.password_manager_enabled", false);

		ChromeOptions options = new ChromeOptions();
		options.merge(capabilities);
		options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		options.setHeadless(HEADLESS);
		options.addArguments("--no-default-browser-check");
		options.setExperimentalOption("prefs", chromePreferences);

		this.driver = new ChromeDriver(options);
		log.debug("%%% Chrome loaded!");
	} 
}
