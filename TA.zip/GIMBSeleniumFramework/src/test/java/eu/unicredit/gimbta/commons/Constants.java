package eu.unicredit.gimbta.commons;

public class Constants {
	public static final String EXECUTION_ENV_LOCAL= "LOCAL";
	public static final String EXECUTION_ENV_REMOTE = "REMOTE";
	
	public static final String USER_DIR_LOCATION = System.getProperty("user.dir");
	public static final String WEBDRIVER_EXECUTABLES_LOCATION = Constants.USER_DIR_LOCATION + "\\src\\test\\resources\\executables\\";
	public static final String FIREFOX_EXE_LOCATION = "C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe";
	
	public static final String LOG4J_CONFIG_PATH = Constants.USER_DIR_LOCATION + "\\src\\test\\resources\\properties\\log4j.properties";
	public static final String EXTENT_REPORT_HTML_PATH = Constants.USER_DIR_LOCATION + "\\target\\surefire-reports\\html\\extent.html";
	public static final String EXTENT_REPORT_CONFIG_PATH = Constants.USER_DIR_LOCATION + "\\src\\test\\resources\\extentconfig\\ReportsConfig.xml";
	
	public static final String CONFIG_EXCEL_LOCATION = Constants.USER_DIR_LOCATION + "\\src\\test\\resources\\excel\\";
	public static final String TEST_LIST_SHEET = "TestSuite";
	
	public static final String MESSAGE_PROPERTIES_PACKAGE_NAME = "i18n.%s.message";
	public static final String MESSAGE_PROPERTIES_FALLBACK_PACKAGE_NAME = "i18n.message";
	public static final String SELECTORS_PROPERTIES_PACKAGE_NAME = "selectors.%s.selectors";
	public static final String SELECTORS_PROPERTIES_FALLBACK_PACKAGE_NAME = "selectors.selectors";
}
