package eu.unicredit.gimbta.utilities;

import java.io.File;

import com.relevantcodes.extentreports.DisplayOrder;
import com.relevantcodes.extentreports.ExtentReports;

import eu.unicredit.gimbta.commons.Constants;

public class ExtentManager {
	
	private static ExtentReports extent;
	
	public static ExtentReports getInstance(){
		if(extent==null) {
			extent = new ExtentReports(Constants.EXTENT_REPORT_HTML_PATH, true, DisplayOrder.OLDEST_FIRST);
			extent.loadConfig(new File(Constants.EXTENT_REPORT_CONFIG_PATH));
		}
		return extent;	
	}
}
