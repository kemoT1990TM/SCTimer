package eu.unicredit.gimbta.testcase.base;

import java.io.FileInputStream;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;

import com.relevantcodes.extentreports.ExtentTest;

import eu.unicredit.gimbta.commons.Constants;
import eu.unicredit.gimbta.data.DataProvider;
import eu.unicredit.gimbta.data.SelectorBean;
import eu.unicredit.gimbta.data.SelectorModes;
import eu.unicredit.gimbta.utilities.ExtendedResource;
import eu.unicredit.gimbta.utilities.TestUtil;
import eu.unicredit.gimbta.webdriver.GenericWebDriver;

public class TestBase {
	protected static final Logger log = Logger.getLogger(TestBase.class.getName());	
	protected static final int EXPLICIT_DRIVER_WAIT = 10;
	private static final Boolean USE_REMOTE_DRIVER = Boolean.getBoolean("remoteDriver");
	private static ThreadLocal<Map<String, DataProvider>> testSuiteData = new ThreadLocal<Map<String, DataProvider>>();
	private static ThreadLocal<GenericWebDriver> driver = new ThreadLocal<GenericWebDriver>();
	private static ThreadLocal<ExtentTest> extTest = new ThreadLocal<ExtentTest>();
	private static ThreadLocal<ExtentTest> test = new ThreadLocal<ExtentTest>();
	
	protected static ThreadLocal<String> loginURL = new ThreadLocal<String>();
	protected static ThreadLocal<Locale> currentLocale = new ThreadLocal<Locale>();
	protected static ThreadLocal<ExtendedResource> messages = new ThreadLocal<ExtendedResource>();
	protected static ThreadLocal<ExtendedResource> selectors = new ThreadLocal<ExtendedResource>();
	
	private SelectorBean selector = new SelectorBean();
	protected static Properties config;
	protected static WebDriverWait wait;
	
	public static void setUp(String countryTestParam) {
		if(getDriver() != null)
			return;
		try {
			PropertyConfigurator.configure(Constants.LOG4J_CONFIG_PATH);
			config = getProperties("config", null);
			currentLocale.set(new Locale("it".equals(countryTestParam) ? "it" : "de", countryTestParam.toUpperCase()));
			String browser = USE_REMOTE_DRIVER ? "RemoteGrid" : System.getProperty("browser");
			loginURL.set(config.getProperty(countryTestParam + ".login.url"));
			
			String messagePropertiesPackage = String.format(Constants.MESSAGE_PROPERTIES_PACKAGE_NAME, countryTestParam);
			String selectorsPropertiesPackage = String.format(Constants.SELECTORS_PROPERTIES_PACKAGE_NAME, countryTestParam);
			selectors.set(new ExtendedResource(selectorsPropertiesPackage, 
					Constants.SELECTORS_PROPERTIES_FALLBACK_PACKAGE_NAME, currentLocale.get()));
			messages.set(new ExtendedResource(messagePropertiesPackage, 
					Constants.MESSAGE_PROPERTIES_FALLBACK_PACKAGE_NAME, currentLocale.get()));
			
			testSuiteData.set(TestUtil.loadExcelData(countryTestParam));
			printTestEnvironmentInfo(browser);
			
			log.debug("Instantiating new object from class: eu.unicredit.gimbta.webdriver." + browser + "WebDriver");
			Class<?> webDriverClass = Class.forName("eu.unicredit.gimbta.webdriver." + browser + "WebDriver");
			driver.set((GenericWebDriver) webDriverClass.newInstance());
		
			getDriver().manage().window().maximize();
			getDriver().manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")), TimeUnit.SECONDS);
			wait = new WebDriverWait(getDriver(), EXPLICIT_DRIVER_WAIT);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@AfterMethod
	public void clearCookies() {
		try {
			getDriver().manage().deleteAllCookies();
		} catch (Exception ignored) {
			log.debug("Unable to clear cookies, driver object is not viable...");
		}
	}
	
	private static Properties getProperties(String name, String country) {
		Properties properties = new Properties();
		try (FileInputStream fis = new FileInputStream(Constants.USER_DIR_LOCATION + "\\src\\test\\resources\\properties\\" + 
					name.replace("selectors", "selectors\\selectors_" + country) + ".properties")) {
			properties.load(fis);
			log.debug("%%% " + name + " properties loaded!");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return properties;
	}
	
	private static void printTestEnvironmentInfo(String browser) {
		log.debug("%%% current browser : " + browser);
		log.debug("%%% current country : " + currentLocale.get().getCountry());
		log.debug("%%% current language : " + currentLocale.get().getLanguage());
		log.debug("%%% current gridURL: " + System.getProperty("gridURL"));
		log.debug("%%% current login URL : " + loginURL.get());
		log.debug("%%% current use GRID : " + USE_REMOTE_DRIVER);
	}
	
	public static WebDriver getDriver() {
		if (driver.get() != null)
			return driver.get().getDriver();
		return null;
	}
	
	public static ExtentTest getExtTest() {
		return extTest.get();
	}

	public static void setExtTest(ExtentTest et) {
		extTest.set(et);
	}
	
	public static ExtentTest getTest() {
		return test.get();
	}

	public static void setTest(ExtentTest et) {
		test.set(et);
	}
	
	public String getMessage(String key) {
		return messages.get().getPropertyValue(key);
	}
	
	public String getSelector(String key) {
		checkCurrentSelector(key);
		return this.selector.getSelector();
	}

	public SelectorModes getSelectorMode(String key) {
		checkCurrentSelector(key);
		return this.selector.getMode();
	}
	
	public static Map<String, DataProvider> getSuiteData() {
		return testSuiteData.get();
	}
	
	private void checkCurrentSelector(String key) {
		if(!key.equals(this.selector.getKey()))
			this.selector = new SelectorBean(key, selectors.get().getPropertyValue(key));
	}

	public static void resetDriver() {
		log.debug(String.format("Current thread, closing driver %d", Thread.currentThread().getId()));
		/*driver.remove();
		driver = new ThreadLocal<GenericWebDriver>();*/
	}
	
	public static String getCurrentLanguage() {
		return currentLocale.get().getLanguage();
	}
	
	public static String getCountry() {
		return currentLocale.get().getCountry();
	}
	
	
}
