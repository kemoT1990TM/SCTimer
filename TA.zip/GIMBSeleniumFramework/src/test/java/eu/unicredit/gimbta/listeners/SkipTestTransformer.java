package eu.unicredit.gimbta.listeners;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import eu.unicredit.gimbta.utilities.TestUtil;

public class SkipTestTransformer implements IAnnotationTransformer {
	private static final Logger log = Logger.getLogger(SkipTestTransformer.class.getName());
	
	@Override
	@SuppressWarnings("rawtypes")
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
		System.out.printf("Annotation transformer on method %s %s%n", testMethod.getName(), testClass);
		if (!TestUtil.isTestRunnable(testMethod.getName())) {
			annotation.setEnabled(false);
			log.debug("%%% Test " + testMethod.getName() + " disabled\n");
			System.out.printf("%nTest " + testMethod.getName() + " disabled\n");
	    }
	}

}