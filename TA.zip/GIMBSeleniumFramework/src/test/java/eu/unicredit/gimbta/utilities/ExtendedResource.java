package eu.unicredit.gimbta.utilities;

import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.lang3.StringUtils;

public class ExtendedResource {
	//private static final Logger log = Logger.getLogger(ExtendedResource.class.getName());
	private final Locale defaultLocale;                     // [it_IT / de_AT]
	private final ResourceBundle defaultResourceBundle;     // usually IT or AT dictionary, depending on default starting page
	private final ResourceBundle fallbackResourceBundle;    // default EN dictionary, common to all other locales
	private final String resourcePackageName;

	private Locale currentLocale;
	private ResourceBundle resourceBundle;                  // AT / IT or EN with custom properties, other than common ones in fallbackRB

	public ExtendedResource() {
		this.defaultLocale = null;
		this.resourcePackageName = null;
		this.defaultResourceBundle = null;
		this.fallbackResourceBundle = null;
	}
	
	public ExtendedResource(String localizedResourcePackage, String fallbackResourcePackage, Locale defaultLocale) {
		this.defaultLocale = defaultLocale;
		this.defaultResourceBundle = ResourceBundle.getBundle(localizedResourcePackage, this.defaultLocale);
		this.fallbackResourceBundle = StringUtils.isEmpty(fallbackResourcePackage) ? null : 
										ResourceBundle.getBundle(fallbackResourcePackage, new Locale("en"));
		this.resourcePackageName = localizedResourcePackage;

		this.currentLocale = this.defaultLocale;
		this.resourceBundle = defaultResourceBundle;
	}


	public String getPropertyValue(String key) {
		return getPropertyValue(this.resourceBundle, key);
	}

	public String getPropertyValue(String key, Locale locale) {
		if(!locale.equals(this.currentLocale))
			setLocale(locale);
		return getPropertyValue(key);
	}

	public String peekPropertyValue(String key, Locale locale) {
		ResourceBundle tmp = ResourceBundle.getBundle(this.resourcePackageName, locale);
		return getPropertyValue(tmp, key);
	}

	public void reset() {
		this.currentLocale = defaultLocale;
		this.resourceBundle = defaultResourceBundle;
	}

	public Locale getCurrentLocale() {
		return this.currentLocale;
	}

	public void setLocale(Locale locale) {
		this.currentLocale = locale;
		setResourceBundle(locale);
	}

	public long getTimeToLive() {
		ResourceBundle.Control rbc = ResourceBundle.Control.getControl(ResourceBundle.Control.FORMAT_PROPERTIES);
		return rbc.getTimeToLive(resourcePackageName, currentLocale);
	}


	private void setResourceBundle(Locale locale) {
		try {
			this.resourceBundle = ResourceBundle.getBundle(this.resourcePackageName, locale);
		} catch (MissingResourceException mre) {
			if (locale.equals(Locale.ENGLISH) && fallbackResourceBundle != null) {
				this.resourceBundle = fallbackResourceBundle;
			}
		}
	}

	private String getPropertyValue(ResourceBundle resBundle, String key) {
		try {
			//log.debug(String.format("key is: %s, resBundleName: %s, defaultLocale is %s", key, resBundle.getBaseBundleName(), Locale.getDefault()));
			if(resBundle.containsKey(key))
				return resBundle.getString(key);
			return fallbackResourceBundle.getString(key);
		} catch (NullPointerException npe) {
		} catch (MissingResourceException mre) {
		}
		return null;
	}
}
