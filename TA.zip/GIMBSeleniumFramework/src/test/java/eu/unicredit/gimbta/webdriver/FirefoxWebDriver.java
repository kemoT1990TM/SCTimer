package eu.unicredit.gimbta.webdriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import eu.unicredit.gimbta.commons.Constants;

public class FirefoxWebDriver extends GenericWebDriver {
	
	public FirefoxWebDriver() {
		super();
		System.setProperty("webdriver.gecko.driver", Constants.WEBDRIVER_EXECUTABLES_LOCATION + "geckodriver.exe");
		System.setProperty("webdriver.firefox.bin", Constants.FIREFOX_EXE_LOCATION);
		
		FirefoxOptions options = new FirefoxOptions();
		options.merge(capabilities);
		options.setCapability("marionette", true);
		options.merge(capabilities);
		options.setHeadless(HEADLESS);

		this.driver = new FirefoxDriver(options);
		log.debug("%%% Firefox loaded!");
	}
}
