package eu.unicredit.gimbta.webdriver;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;

import eu.unicredit.gimbta.commons.Constants;

public class IEWebDriver extends GenericWebDriver {

	public IEWebDriver() {
		super();
		System.setProperty("webdriver.ie.driver", Constants.WEBDRIVER_EXECUTABLES_LOCATION + "IEDriverServer.exe");

		InternetExplorerOptions options = new InternetExplorerOptions();
		options.merge(capabilities);
		options.setCapability(CapabilityType.ForSeleniumServer.ENSURING_CLEAN_SESSION, true);
		options.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, true);
		options.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);

		setDriver(new InternetExplorerDriver(options));
		log.debug("%%% IE loaded!");
	}
}
