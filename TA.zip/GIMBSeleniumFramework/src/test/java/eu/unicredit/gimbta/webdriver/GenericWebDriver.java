package eu.unicredit.gimbta.webdriver;

import static org.openqa.selenium.Proxy.ProxyType.MANUAL;
import static org.openqa.selenium.remote.CapabilityType.PROXY;

import org.apache.log4j.Logger;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class GenericWebDriver {
	static final Logger log = Logger.getLogger("gimbLogger");	
	
	static final boolean proxyEnabled = Boolean.getBoolean("proxyEnabled");
	static final String proxyHostname = System.getProperty("proxyHost");
	static final Integer proxyPort = Integer.getInteger("proxyPort");
	static final String proxyDetails = String.format("%s:%d", proxyHostname, proxyPort);
	static final boolean HEADLESS = Boolean.getBoolean("headless");
	
	DesiredCapabilities capabilities;
	WebDriver driver;
	
	public GenericWebDriver() {
		capabilities = new DesiredCapabilities();
		if (proxyEnabled) {
			Proxy proxy = new Proxy();
			proxy.setProxyType(MANUAL);
			proxy.setHttpProxy(proxyDetails);
			proxy.setSslProxy(proxyDetails);
			capabilities.setCapability(PROXY, proxy);
		}
	}
	
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebDriver getDriver() {
		return this.driver;
	}
	
}
