package eu.unicredit.gimbta.testcase.base;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.LogStatus;

import eu.unicredit.gimbta.utilities.TestUtil;

public class TestCommons extends TestBase {
	private WebElement dropdown;

	public WebElement getElement(String locator) {
		log.debug(String.format("getSelectorMode called for %s, with mode %s and selector %s", locator, getSelectorMode(locator), getSelector(locator)));
		switch(getSelectorMode(locator)) {
			case id:	return getDriver().findElement(By.id(getSelector(locator)));
			case css:	return getDriver().findElement(By.cssSelector(getSelector(locator)));
			case name:	return getDriver().findElement(By.name(getSelector(locator)));
			case xpath:	return getDriver().findElement(By.xpath(getSelector(locator)));
			default:	return null;
		}
	}

	public List<WebElement> getListOfElements(String locator) {
		log.debug(String.format("getSelectorMode called for %s, with mode %s and selector %s", locator, getSelectorMode(locator), getSelector(locator)));
		switch(getSelectorMode(locator)) {
			case id:	return getDriver().findElements(By.id(getSelector(locator)));
			case css:	return getDriver().findElements(By.cssSelector(getSelector(locator)));
			case name:	return getDriver().findElements(By.name(getSelector(locator)));
			case xpath:	return getDriver().findElements(By.xpath(getSelector(locator)));
			default:	return null;
		}
	}

	public WebElement getElementFromList(String locator, int index) {
		return getListOfElements(locator).get(index);
	}
	
	/*
	 * This will attempt to find and click the element. If the DOM changes between
	 * the find and click, it will try again. The idea is that if it failed and try
	 * again immediately the second attempt will succeed.
	 */
	public void retryingFindClick(String locator) {
		int attempts = 0;
		WebElement domElement = getElement(locator); 
		while (attempts < 5) {
			try {
				if(domElement != null && domElement.isEnabled() && domElement.isDisplayed()) {
					click(locator);
					break;
				}
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}
	}

	public void wait(String locator) {
		wait = new WebDriverWait(getDriver(), TestBase.EXPLICIT_DRIVER_WAIT);
		log.debug(String.format("getSelectorMode called for %s, with mode %s and selector %s", locator, getSelectorMode(locator), getSelector(locator)));
		switch(getSelectorMode(locator)) {
			case id:	wait.until(ExpectedConditions.presenceOfElementLocated(By.id(getSelector(locator))));
						break;
			case css:	wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(getSelector(locator))));
						break;
			case name:	wait.until(ExpectedConditions.presenceOfElementLocated(By.name(getSelector(locator))));
						break;
			case xpath:	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(getSelector(locator))));
						break;
		}
		getTest().log(LogStatus.INFO, "Waiting for: " + locator);
	}

	public void click(String locator) {
		wait(locator);
		getElement(locator).click();
		getExtTest().log(LogStatus.INFO, "Click on: " + locator);
	}

	public void type(String locator, String value) {
		getElement(locator).clear();
		getElement(locator).sendKeys(value);
		getExtTest().log(LogStatus.INFO, "Type in: " + locator + " -> " + value);

	}

	public void sendKeys(String locator, String value) {
		getElement(locator).sendKeys(value);
		getExtTest().log(LogStatus.INFO, "SendKeys in: " + locator + " -> " + value);

	}

	public String getText(String locator) {
		getExtTest().log(LogStatus.INFO, "Get text from: " + locator);
		return getElement(locator).getText();
	}

	public String getValue(String locator) {
		getExtTest().log(LogStatus.INFO, "Get value from: " + locator);
		return getElement(locator).getAttribute("value");
	}

	/*
	 * isDisplayed will return FALSE also if multiple elements are found for "locator".
	 * In such case use alternative locators to narrow down search results.
	 */
	public boolean isDisplayed(String locator) {
		if (getElement(locator).isDisplayed()) {
			getExtTest().log(LogStatus.PASS, "Element: " + locator + " is displayed");
			return true;
		}
		getExtTest().log(LogStatus.WARNING, "Element: " + locator + " is not displayed");
		getExtTest().log(LogStatus.WARNING, "Element: " + getElement(locator).getAttribute("class"));
		getExtTest().log(LogStatus.WARNING, "Element: " + getElement(locator).getSize());
		return false;
	}

	public boolean isEditable(String locator) {
		if (/*isDisplayed(locator) && */getElement(locator).isEnabled()) {
			getExtTest().log(LogStatus.PASS, "Element: " + locator + " is displayed and enabled");
			return true;
		}
		getExtTest().log(LogStatus.WARNING, "Element: " + locator + " / " + getSelector(locator) + " is not displayed and enabled");
		return false;
	}

	public void select(String locator, String value) {
		dropdown = getElement(locator);
		Select select = new Select(dropdown);
		select.selectByVisibleText(value);
		getExtTest().log(LogStatus.INFO, "Select from dropdown: " + locator + " -> " + value);
	}

	public void softAssertText(String locator, String value) {
		try {
			Assert.assertEquals(getText(locator), value);
			getExtTest().log(LogStatus.PASS, "Assertion passed for: " + locator + " with expected value: " + value);
		} catch (Throwable t) {
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e) {
				e.printStackTrace();
			}
			getExtTest().log(LogStatus.WARNING, getTest().addScreenCapture(TestUtil.screenshotName));
			getExtTest().log(LogStatus.WARNING, "Soft Assertion failed for: " + locator + " with expected value: " + value);
		}
	}

	public void softAssertValue(String locator, String value) {
		try {
			Assert.assertEquals(getValue(locator), value);
			getExtTest().log(LogStatus.PASS, "Assertion passed for: " + locator + " with expected value: " + value);
		} catch (Throwable t) {
			try {
				TestUtil.captureScreenshot();
			} catch (IOException e) {
				e.printStackTrace();
			}
			getExtTest().log(LogStatus.WARNING, getTest().addScreenCapture(TestUtil.screenshotName));
			getExtTest().log(LogStatus.WARNING, "Soft Assertion failed for: " + locator + " with expected value: " + value);
		}
	}

	public void hardAssertText(String locator, String value) throws IOException {
		try {
			Assert.assertEquals(getText(locator), value);
			getExtTest().log(LogStatus.PASS, "Assertion passed for: " + locator + " with expected value: " + value);
		} catch (Throwable t) {
			TestUtil.captureScreenshot();
			getExtTest().log(LogStatus.FAIL, getTest().addScreenCapture(TestUtil.screenshotName));
			getExtTest().log(LogStatus.FAIL, "Soft Assertion failed for: " + locator + " with expected value: " + value);
		}
	}

	public void hardAssertValue(String locator, String value) throws IOException {
		try {
			Assert.assertEquals(getValue(locator), value);
			getExtTest().log(LogStatus.PASS, "Assertion passed for: " + locator + " with expected value: " + value);
		} catch (Throwable t) {
			TestUtil.captureScreenshot();
			getExtTest().log(LogStatus.FAIL, getTest().addScreenCapture(TestUtil.screenshotName));
			getExtTest().log(LogStatus.FAIL, "Soft Assertion failed for: " + locator + " with expected value: " + value);
		}
	}

	public void verifyEquals(String expected, String actual) throws IOException {
		try {
			Assert.assertEquals(actual, expected);
		} catch (Throwable t) {
			TestUtil.captureScreenshot();
			getExtTest().log(LogStatus.FAIL, "Verification failed with exception : " + t.getMessage());
			getExtTest().log(LogStatus.FAIL, getTest().addScreenCapture(TestUtil.screenshotName));
			throw t;
		}
	}

	public void softVerifyEquals(String expected, String actual) throws IOException {
		try {
			Assert.assertEquals(actual, expected);
		} catch (Throwable t) {
			TestUtil.captureScreenshot();
			getExtTest().log(LogStatus.WARNING, "Verification failed with exception : " + t.getMessage());
			getExtTest().log(LogStatus.WARNING, getTest().addScreenCapture(TestUtil.screenshotName));
		}
	}
}
