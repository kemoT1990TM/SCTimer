package eu.unicredit.gimbta.data;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DataProvider {
	private List<Map<String, String>> dataProvider;

	public DataProvider() {
		this.dataProvider = new LinkedList<Map<String, String>>();
	}

	public void addEntry(Map<String, String> entry) {
		this.dataProvider.add(entry);
	}
	
	public Object[][] getDataProvider() {
		Object[][] data = new Object[this.dataProvider.size()][1];
		for(int i=0; i<dataProvider.size(); i++)
			data[i][0] = dataProvider.get(i);
		return data;
	}	
	
}
