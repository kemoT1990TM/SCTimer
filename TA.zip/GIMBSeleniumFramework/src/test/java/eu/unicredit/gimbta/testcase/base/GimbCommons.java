package eu.unicredit.gimbta.testcase.base;

import static org.junit.Assert.assertTrue;

import java.util.Hashtable;
import java.util.Locale.Builder;

import org.openqa.selenium.Keys;
import org.testng.Reporter;

import com.relevantcodes.extentreports.LogStatus;

import eu.unicredit.gimbta.commons.SelectorKeys;

public class GimbCommons extends TestCommons {

	protected void setExtReportTestName(String testName) {
		getExtTest().getTest().setName(testName);
	}
	
	protected void resetLocale() {
		String language = "it".equalsIgnoreCase(currentLocale.get().getCountry())  ? "it" : "de";
		currentLocale.set(new Builder().setLanguage(language).setRegion(currentLocale.get().getCountry()).build());
		messages.get().reset();
		selectors.get().reset();
	}
	
	protected void setLocale(String language) {
		currentLocale.set(new Builder().setLanguage(language).setRegion(currentLocale.get().getCountry()).build());
		messages.get().setLocale(currentLocale.get());
		selectors.get().setLocale(currentLocale.get());
	}
	
	protected void openLoginPage() {
		getDriver().get(loginURL.get());
		log.debug("%%% Launched URL: " + loginURL.get());
		verifyURL();
		if("it".equals(currentLocale.get().getLanguage())) {
			log.debug("Clicking on : " + getSelector(SelectorKeys.LOGIN_FORM_ID));
			click(SelectorKeys.LOGIN_FORM_ID);
		}
	}

	protected void doLogin(Hashtable<String, String> data) {
//		verifyURL();
//		if("it".equals(currentLocale.get().getLanguage())) {
//			log.debug("Clicking on : " + getSelector(SelectorKeys.LOGIN_FORM_ID));
//			click(SelectorKeys.LOGIN_FORM_ID);
//		}
		click(SelectorKeys.USERCODE_FIELD_SELECTOR);
		type(SelectorKeys.USERCODE_FIELD_SELECTOR, data.get("usercode"));
		sendKeys(SelectorKeys.USERCODE_FIELD_SELECTOR, Keys.TAB + data.get("pin"));
		click(SelectorKeys.LOGIN_BUTTON_SELECTOR);
		wait(SelectorKeys.HOMEPAGE_MENU_SELECTOR);
		assertTrue(isEditable(SelectorKeys.HOMEPAGE_MENU_SELECTOR));
	}

	private void verifyURL() {
		getExtTest().log(LogStatus.INFO, "Before login - Verifying that the URL is UAT env: " + loginURL.get());
		//Assert.assertEquals(getDriver().getCurrentUrl(), loginURL.get());
		if(!getDriver().getCurrentUrl().startsWith(loginURL.get()))
			throw new java.lang.AssertionError(String.format("Expected login URL: %s, found %s", loginURL.get(), getDriver().getCurrentUrl()));
		getExtTest().log(LogStatus.PASS, "Assertion passed for: URL check with expected value: " + loginURL.get());
	}

	protected void doLogout() {
		click(SelectorKeys.LOGOUT_SELECTOR);
	}

	protected void logPassed(String testName) {
		log.debug("%%% " + testName + " - PASS!\n");
		Reporter.log(testName + " - PASS");
	}

}
