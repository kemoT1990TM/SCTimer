package eu.unicredit.gimbta.testcase;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Hashtable;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import eu.unicredit.gimbta.commons.SelectorKeys;
import eu.unicredit.gimbta.testcase.base.GimbCommons;
import eu.unicredit.gimbta.utilities.TestUtil;

public class BilancioFamiliareTest extends GimbCommons {

	@Test(dataProviderClass=TestUtil.class, dataProvider="dp")
	public void checkBilancioFamiliareHomepage(Hashtable<String, String> data, ITestContext ctx) throws Exception {
		setExtReportTestName(ctx.getName() + " :: " + data.get("testName"));
		log.debug("STARTING TEST testName: " + data.get("testName"));
		log.debug("STARTING TEST ctx.getName(): " + ctx.getName());
		log.debug("Language: " + currentLocale.get().getLanguage());
		
		// ---------------------- Test Case steps ----------------------
		
		checkFamilyBalancePage(data);
		
		// --------------------------------------------------------
		logPassed(data.get("testName"));
	}

	@Test(dataProviderClass=TestUtil.class, dataProvider="dp")
	public void categoryDetailsTest(Hashtable<String, String> data, ITestContext ctx) throws Exception {
		setExtReportTestName(ctx.getName() + " :: " + data.get("testName"));
		log.debug("STARTING TEST testName: " + data.get("testName"));
		log.debug("STARTING TEST ctx.getName(): " + ctx.getName());
		log.debug("Language: " + currentLocale.get().getLanguage());
		
		// ---------------------- Test Case steps ----------------------
		
		checkFamilyBalancePage(data);
		
		// --------------------------------------------------------
		logPassed(data.get("testName"));
	}

	private void checkFamilyBalancePage(Hashtable<String, String> data) throws IOException {
		openLoginPage();
		doLogin(data);
		isFamilyBalancePageDisplayed();
		doLogout();
	}
	
	private void isFamilyBalancePageDisplayed() throws IOException {
		click(SelectorKeys.FAMILY_BALANCE_SELECTOR);
		wait(SelectorKeys.FAMILY_BALANCE_INCOMING_TAB_ID);
		hardAssertText(SelectorKeys.FAMILY_BALANCE_HEADER, "Bilancio Familiare");
		assertTrue("Incoming Tab is not displayed", isDisplayed(SelectorKeys.FAMILY_BALANCE_INCOMING_TAB_ID));
		assertTrue("Expenses Tab is not displayed", isDisplayed(SelectorKeys.FAMILY_BALANCE_EXPENSES_TAB_ID));
		assertTrue("Comparision Tab is not displayed", isDisplayed(SelectorKeys.FAMILY_BALANCE_COMPARE_TAB_ID));
		assertTrue("Chart is not displayed", isDisplayed(SelectorKeys.FAMILY_BALANCE_CHART_ID));
		assertTrue("Current month value is not displayed", isDisplayed(SelectorKeys.FAMILY_BALANCE_MONTH_VALUE_SELECTOR));
		assertTrue("List of Transactions is empty", getListOfElements(SelectorKeys.FAMILY_BALANCE_TRANSACTION_LIST_SELECTOR).get(0).isDisplayed());
	}
}
