package eu.unicredit.gimbta.commons;

public class MessageKeys {

	public static final String ERROR_MSG_LOGIN_WRONG_USER = "login.errormessage.user.ko";
	
}
