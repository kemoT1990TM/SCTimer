package eu.unicredit.gimbta.testcase;

import static org.junit.Assert.assertTrue;

import java.util.Hashtable;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import eu.unicredit.gimbta.commons.SelectorKeys;
import eu.unicredit.gimbta.commons.MessageKeys;
import eu.unicredit.gimbta.testcase.base.GimbCommons;
import eu.unicredit.gimbta.utilities.TestUtil;

public class LoginPageTest extends GimbCommons {

	@Test(dataProviderClass=TestUtil.class, dataProvider="dp")
	public void loginTest(Hashtable<String, String> data, ITestContext ctx) throws Exception {
		setExtReportTestName(ctx.getName() + " :: " + data.get("testName"));
		// ---------------------- Test Case steps ----------------------
		
		resetLocale();
		openLoginPage();
		doLogin(data);
		doLogout();
		
		// --------------------------------------------------------
		logPassed(data.get("testName"));
	}
	
	@Test(dataProviderClass=TestUtil.class, dataProvider="dp")
	public void loginScreenCheck(Hashtable<String,String> data, ITestContext ctx) throws Exception {
		setExtReportTestName(ctx.getName() + " :: " + data.get("testName"));
		// ---------------------- Test Case steps ----------------------
		
		resetLocale();
		openLoginPage();
		assertTrue(isEditable(SelectorKeys.USERCODE_FIELD_SELECTOR));
		assertTrue(isEditable(SelectorKeys.PIN_FIELD_SELECTOR));
		assertTrue(isEditable(SelectorKeys.LOGIN_BUTTON_SELECTOR));

		type(SelectorKeys.USERCODE_FIELD_SELECTOR, data.get("usercode"));
		getExtTest().log(LogStatus.INFO, "Check if usercode is 8 characters long.");
		hardAssertValue(SelectorKeys.USERCODE_FIELD_SELECTOR, data.get("usercode").substring(0, 8));
		
		// --------------------------------------------------------
		logPassed(data.get("testName"));
	}

	@Test(dataProviderClass=TestUtil.class, dataProvider="dp")
	public void checkUserCodeAndPin(Hashtable<String,String> data, ITestContext ctx) throws Exception {
		setExtReportTestName(ctx.getName() + " :: " + data.get("testName"));
		// ---------------------- Test Case steps ----------------------
		
		resetLocale();
		openLoginPage();
		doLogin(data);
		wait(SelectorKeys.LOGIN_MESSAGE_SELECTOR);
		getExtTest().log(LogStatus.INFO, "Verifying that the correct message appears with invalid login parameters.");
		hardAssertText(SelectorKeys.LOGIN_MESSAGE_SELECTOR, getMessage(MessageKeys.ERROR_MSG_LOGIN_WRONG_USER));

		getExtTest().log(LogStatus.INFO, "Change language to English");
		retryingFindClick(SelectorKeys.LANGUAGE_CHANGE_SELECTOR);
		log.debug("after click lang change: " + Thread.currentThread().getId());
		
		setLocale("en");
		
		log.debug("before doLogin: " + Thread.currentThread().getId());
		doLogin(data);
		log.debug("after doLogin: " + Thread.currentThread().getId());
		wait(SelectorKeys.LOGIN_MESSAGE_SELECTOR);
		getExtTest().log(LogStatus.INFO, "Verifying that the correct message appears with invalid login parameters.");
		hardAssertText(SelectorKeys.LOGIN_MESSAGE_SELECTOR, getMessage(MessageKeys.ERROR_MSG_LOGIN_WRONG_USER));
		
		// --------------------------------------------------------
		logPassed(data.get("testName"));
	}

}
