package eu.unicredit.gimbta.utilities;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import eu.unicredit.gimbta.commons.Constants;
import eu.unicredit.gimbta.data.DataProvider;
import eu.unicredit.gimbta.testcase.base.TestBase;

public class TestUtil {
	//private static final Logger log = Logger.getLogger(TestUtil.class.getName());
	public static String screenshotPath;
	public static String screenshotName;
	
	public static void captureScreenshot() throws IOException {
		File scrFile = ((TakesScreenshot) TestBase.getDriver()).getScreenshotAs(OutputType.FILE);
		Date d = new Date();
		screenshotName = d.toString().replace(":", "_").replace(" ", "_") + ".jpg";
		FileUtils.copyFile(scrFile, new File(Constants.USER_DIR_LOCATION + "\\target\\surefire-reports\\html\\" + screenshotName));
	}

	@org.testng.annotations.DataProvider(name="dp")
	public Object[][] getData(Method m) {
		return TestUtil.isTestRunnable(m.getName()) ? TestBase.getSuiteData().get(m.getName()).getDataProvider() : new Object[1][1];
	}
	
	public static boolean isTestRunnable(String testName) {
		//System.out.printf("Test %s is runnable: %s %n", testName, TestBase.getSuiteData().containsKey(testName));
		return TestBase.getSuiteData().containsKey(testName);
	}
		
	public static Map<String, DataProvider> loadExcelData(String country) {
		Map<String, DataProvider> testData = new HashMap<String, DataProvider>();
		final File folder = new File(Constants.CONFIG_EXCEL_LOCATION + country.toLowerCase());
		for (final File fileEntry : folder.listFiles()) {
			ExcelReader excelReader = new ExcelReader(fileEntry.getAbsolutePath());
			int testListSheetRows = excelReader.getRowCount(Constants.TEST_LIST_SHEET);
			DataProvider dataProvider = null;
			Map<String, String> dataProviderEntry = null;
			for(int rNum=2; rNum<=testListSheetRows; rNum++){
				String testCaseId = excelReader.getCellData(Constants.TEST_LIST_SHEET, "testCaseId", rNum);
				String testName = excelReader.getCellData(Constants.TEST_LIST_SHEET, "testCaseName", rNum);
				String runmode = excelReader.getCellData(Constants.TEST_LIST_SHEET, "run", rNum);
				if(runmode.equalsIgnoreCase("y")) {
					dataProvider = new DataProvider();
					int testCaseSheetRows = excelReader.getRowCount(testCaseId);
					int testCaseSheetCols = excelReader.getRowCount(testCaseId);
					for (int rowNum = 2; rowNum <= testCaseSheetRows; rowNum++) {
						dataProviderEntry = new Hashtable<String, String>();
						if(!excelReader.getCellData(testCaseId, "run", rowNum).equalsIgnoreCase("y"))
							continue;
						for (int colNum = 0; colNum < testCaseSheetCols; colNum++) {
							String propertyName = excelReader.getCellData(testCaseId, colNum, 1);
							String propertyValue = excelReader.getCellData(testCaseId, colNum, rowNum);
							dataProviderEntry.put(propertyName, propertyValue);
						}
						dataProviderEntry.put("testName", testName);
						dataProvider.addEntry(dataProviderEntry);
					}
					testData.put(testCaseId, dataProvider);
				}
			}
		}
		//printTestData(testData, country);
		return testData;
	}
	
	private static void printTestData(Map<String, DataProvider> data, String country) {
		data.forEach((m, dp) -> {
			System.out.printf("%nMethod %s, dataProvider %s, country %s", m, dp.getDataProvider().length, country);
		});
	}
}
