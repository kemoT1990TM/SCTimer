package eu.unicredit.gimbta.commons;

public class SelectorKeys {

	/* --------------------------   LOGIN SECTION  --------------------------- */
	public static final String LOGIN_FORM_ID = "login.form";
	public static final String HOMEPAGE_MENU_SELECTOR = "login.menu";
	public static final String ACCOUNT_HEADER_SELECTOR = "account.header";
	public static final String LANGUAGE_CHANGE_SELECTOR = "login.language.change";
	public static final String LOGIN_MESSAGE_SELECTOR = "login.message";
	public static final String LOGIN_BUTTON_SELECTOR = "login.button";
	public static final String PIN_FIELD_SELECTOR = "login.pin";
	public static final String USERCODE_FIELD_SELECTOR = "login.usercode";
	public static final String LOGOUT_SELECTOR = "logout.link";

	// -- FAMILY BALANCE SELECTORS --
	public static final String FAMILY_BALANCE_ID = "family.balance";
	public static final String FAMILY_BALANCE_SELECTOR = "family.balance";
	public static final String FAMILY_BALANCE_HEADER = "family.balance.header";
	public static final String FAMILY_BALANCE_CHART_ID = "family.balance.chart";
	public static final String FAMILY_BALANCE_MONTH_VALUE_SELECTOR = "family.balance.month.value";
	public static final String FAMILY_BALANCE_TRANSACTION_LIST_SELECTOR = "family.balance.transaction.list";
	public static final String FAMILY_BALANCE_EXPENSES_TAB_ID = "family.balance.expenses.tab";
	public static final String FAMILY_BALANCE_INCOMING_TAB_ID = "family.balance.incoming.tab";
	public static final String FAMILY_BALANCE_COMPARE_TAB_ID = "family.balance.compare.tab";

	// -- USER HEADER SELECTORS
	public static final String USER_HEADER_ID = "user.header";
	public static final String USER_HEADER_DOCUMENTS_LINK_ID = "user.header.documents.link";

}
