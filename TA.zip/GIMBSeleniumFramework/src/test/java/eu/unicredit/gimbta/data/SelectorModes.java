package eu.unicredit.gimbta.data;

public enum SelectorModes {
	xpath, css, id, name
};